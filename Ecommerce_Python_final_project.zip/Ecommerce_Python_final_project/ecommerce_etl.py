import pandas as pd
#Reading files
print("Reading customer File")
customers_df=pd.read_csv(r"C:\Users\Home\Documents\Python_Notes\Ecommerce_Python_final_project\Input\customer_source.csv")
print(customers_df)
print("Reading Products File")
products_df=pd.read_csv(r"C:\Users\Home\Documents\Python_Notes\Ecommerce_Python_final_project\Input\product_source.csv")
print(products_df)
print("Reading orders File")
orders_df=pd.read_csv(r"C:\Users\Home\Documents\Python_Notes\Ecommerce_Python_final_project\Input\orders.csv")
print(orders_df)
print("Data Readed successfully")

#Profiling
print("CUSTOMER DATA")
print("Number of rows & Columns : ",customers_df.shape)
print("column Names :",customers_df.columns)
print("Data Types")
print(customers_df.dtypes)
print("Missing Values")
print(customers_df.isnull().sum())
print("Duplicates:", customers_df.duplicated().sum())


print("\nORDERS DATA")
print("Number of rows & Columns : ", orders_df.shape)
print("column Names :",orders_df.columns)
print("Data Types")
print(orders_df.dtypes)
print("Missing Values")
print(orders_df.isnull().sum())
print("Duplicates:", orders_df.duplicated().sum())


print("\nPRODUCT DATA")
print("Number of rows & Columns : ",products_df.shape)
print("column Names :",products_df.columns)
print("Data Types")
print(products_df.dtypes)
print("Missing Values")
print(products_df.isnull().sum())
print("Duplicates:", products_df.duplicated().sum())

#Customer_Cleaning
print("Original Product Data")
print(customers_df)

# 1. Remove extra spaces
customers_df['customer_name'] = customers_df['customer_name'].str.strip()
customers_df['Email'] = customers_df['Email'].str.strip()
customers_df['City'] = customers_df['City'].str.strip()

# 2. Handle different capitalization
customers_df['customer_name'] = customers_df['customer_name'].str.title()
customers_df['Email'] = customers_df['Email'].str.lower()
customers_df['City'] = customers_df['City'].str.title()

# 3. Handle missing customer name
customers_df['customer_name'] = customers_df['customer_name'].fillna('Unknown')

# 4. Handle missing email
customers_df['Email'] = customers_df['Email'].fillna('Not Available')

# 5. Handle missing city
customers_df['City'] = customers_df['City'].fillna('Unknown')

# 6. Validate email
email_pattern = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'

invalid_email = (
    (customers_df['Email'] != 'Not Available') &
    (~customers_df['Email'].str.match(email_pattern, na=False))
)

customers_df.loc[invalid_email, 'Email'] = 'Invalid Email'

# 7. Remove duplicate customers
customers_df = customers_df.drop_duplicates(
    subset=['customer_id'],
    keep='first'
)

# Reset index
customers_df = customers_df.reset_index(drop=True)

print("\nCleaned Customer Data:")
print(customers_df)

#Product_Cleaning
print("Original Data")
print(products_df)

# -----------------------------
# STEP 1: CLEAN DATA
# -----------------------------

# Remove extra spaces
products_df['product_id'] = products_df['product_id'].str.strip()
products_df['product_name'] = products_df['product_name'].str.strip()
products_df['category'] = products_df['category'].str.strip()

# Standardize capitalization
products_df['product_name'] = products_df['product_name'].str.title()
products_df['category'] = products_df['category'].str.title()


# -----------------------------
# STEP 2: IDENTIFY REJECTS
# -----------------------------

reject_condition = (
    products_df['product_id'].isna() |
    products_df['product_name'].isna() |
    products_df['category'].isna() |
    products_df['price'].isna() |
    (products_df['stock'] < 0)
)


# -----------------------------
# STEP 3: REJECT DATA
# -----------------------------

reject_products_df = products_df[reject_condition].copy()

print("\nRejected Products:")
print(reject_products_df)


# -----------------------------
# STEP 4: CLEAN DATA
# -----------------------------

clean_products_df = products_df[~reject_condition].copy()

print("\nClean Products:")
print(clean_products_df)

#orders_cleaning
print("Original Orders:")
print(orders_df)


# -----------------------------
# STEP 1: CLEAN SPACES
# -----------------------------

orders_df['order_id'] = orders_df['order_id'].astype(str).str.strip()
orders_df['customer_id'] = orders_df['customer_id'].astype(str).str.strip()
orders_df['product_id'] = orders_df['product_id'].astype(str).str.strip()
orders_df['status'] = orders_df['status'].str.strip()


# -----------------------------
# STEP 2: VALIDATE CUSTOMER
# -----------------------------

valid_customer_ids = customers_df['customer_id'].dropna().unique()

customer_condition = orders_df['customer_id'].isin(valid_customer_ids)


# -----------------------------
# STEP 3: VALIDATE PRODUCT
# -----------------------------

valid_product_ids = products_df['product_id'].dropna().unique()

product_condition = orders_df['product_id'].isin(valid_product_ids)


# -----------------------------
# STEP 4: VALIDATE QUANTITY
# -----------------------------

quantity_condition = orders_df['quantity'] > 0


# -----------------------------
# STEP 5: VALIDATE PRICE
# -----------------------------

price_condition = orders_df['price'] >= 0


# -----------------------------
# STEP 6: VALIDATE DATE
# -----------------------------

orders_df['order_date'] = pd.to_datetime(
    orders_df['order_date'],
    errors='coerce'
)

date_condition = orders_df['order_date'].notna()


# -----------------------------
# STEP 7: VALIDATE ORDER ID
# -----------------------------

unique_order_condition = ~orders_df['order_id'].duplicated(keep=False)


# -----------------------------
# STEP 8: COMBINE ALL RULES
# -----------------------------

valid_condition = (
    customer_condition &
    product_condition &
    quantity_condition &
    price_condition &
    date_condition &
    unique_order_condition
)


# -----------------------------
# STEP 9: CLEAN ORDERS
# -----------------------------

clean_orders_df = orders_df[valid_condition].copy()

print("\nClean Orders:")
print(clean_orders_df)


# -----------------------------
# STEP 10: REJECT ORDERS
# -----------------------------

reject_orders_df = orders_df[~valid_condition].copy()

print("\nRejected Orders:")
print(reject_orders_df)

#API HANDLING

import requests
import pandas as pd

# Step 1: Define the API URL
api_url = "https://jsonplaceholder.typicode.com/users"

# Step 2: Send a GET request
response = requests.get(api_url, timeout=30)

# Step 3: Inspect the response status
print("Response Status Code:", response.status_code)

# Step 4: Check whether the request was successful
response.raise_for_status()

# Step 5: Inspect the response content
print("\nResponse Content:")
print(response.text[:500])

# Step 6: Inspect the response data type
print("\nResponse Object Type:", type(response))
print("Response Content Type:", response.headers.get("Content-Type"))

# Step 7: Convert the JSON response into Python data
api_data = response.json()

print("\nAPI Data Type:", type(api_data))
print("Number of Users:", len(api_data))

# Step 8: Display the first user's information
print("\nFirst User:")
print(api_data[0])

# Step 9: Extract the required fields
api_customers = []


for user in api_data:
    customer = {
        "api_customer_id": user["id"],
        "api_customer_name": user["name"],
        "api_email": user["email"],
        "api_city": user["address"]["city"]
    }
    
    api_customers.append(customer)

# Step 10: Convert the extracted data into a DataFrame
api_customers_df = pd.DataFrame(api_customers)
api_customers_df["api_customer_id"] = ( api_customers_df["api_customer_id"].astype("string").str.strip() )

# Step 11: Display the result
print("\nAPI Customer DataFrame:")
print(api_customers_df)

# Step 12: Display DataFrame information
print("\nDataFrame Information:")
print(api_customers_df.info())

# Step 13: Display the DataFrame dimensions
print("\nNumber of Rows and Columns:") 
print(api_customers_df.shape) 
# Step 14: Display column names 
print("\nColumn Names:") 
print(api_customers_df.columns.tolist()) 
# Step 15: Save the DataFrame as a CSV file 
api_customers_df.to_csv("api_customers.csv", index=False) 
print("\nAPI customer data saved successfully!")



# Assume customers_df and api_customers_df
# have already been created.

# Step 1: Display the number of records in each source
print("CSV Customer Count:", len(customers_df))
print("API Customer Count:", len(api_customers_df))


# Step 2: Find customers existing in both sources
common_customers = pd.merge(
    customers_df,
    api_customers_df,
    left_on="customer_id",
    right_on="api_customer_id",
    how="inner"
)

print("\nCustomers Existing in Both Sources:")
print(common_customers)


# Step 3: Find customers existing only in CSV
csv_only = pd.merge(
    customers_df,
    api_customers_df,
    left_on="customer_id",
    right_on="api_customer_id",
    how="left",
    indicator=True
)

csv_only = csv_only[csv_only["_merge"] == "left_only"]

print("\nCustomers Existing Only in CSV:")
print(csv_only[customers_df.columns])


# Step 4: Find customers existing only in API
api_only = pd.merge(
    customers_df,
    api_customers_df,
    left_on="customer_id",
    right_on="api_customer_id",
    how="right",
    indicator=True
)

api_only = api_only[api_only["_merge"] == "right_only"]

print("\nCustomers Existing Only in API:")
print(api_only[api_customers_df.columns])


# Step 5: Compare email values
email_comparison = common_customers[
    common_customers["Email"].fillna("").str.strip().str.lower()
    != common_customers["api_email"].fillna("").str.strip().str.lower()
]

print("\nEmail Differences:")
print(email_comparison[
    ["customer_id", "Email", "api_email"]
])


# Step 6: Compare customer names
name_comparison = common_customers[
    common_customers["customer_name"].fillna("").str.strip().str.lower()
    != common_customers["api_customer_name"].fillna("").str.strip().str.lower()
]

print("\nCustomer Name Differences:")
print(name_comparison[
    ["customer_id", "customer_name"]
])


# Step 7: Compare city values
city_comparison = common_customers[
    common_customers["City"].fillna("").str.strip().str.lower()
    != common_customers["api_city"].fillna("").str.strip().str.lower()
]

print("\nCity Differences:")
print(city_comparison[
    ["customer_id", "City", "api_city"]
])

# 4. Enrich the cleaned customer data 
enriched_customers_df = pd.merge( customers_df, api_customers_df[ [ "api_customer_id"] ], left_on="customer_id", right_on="api_customer_id", how="left", validate="many_to_one" ) 
# 5. Remove the duplicate API ID column 
enriched_customers_df = enriched_customers_df.drop( columns=["api_customer_id"] ) 
# 6. Display enriched customer data 
print("\nEnriched Customer Data:") 
print(enriched_customers_df.head()) 
print("\nEnriched DataFrame Shape:") 
print(enriched_customers_df.shape) 
# 7. Save enriched customer data 
enriched_customers_df.to_csv( "enriched_customers.csv", index=False ) 
print("\nEnriched customer data saved successfully!")


# STEP 16 — Select Only Valid Completed Orders

print("\nSTEP 16: Selecting Valid Completed Orders")

# 1. Create a copy of the orders DataFrame
valid_sales_orders = orders_df.copy()

# 2. Remove records with missing or invalid IDs
valid_sales_orders = valid_sales_orders.dropna(
    subset=['order_id', 'customer_id', 'product_id']
)

# 3. Keep only valid quantities
valid_sales_orders = valid_sales_orders[
    valid_sales_orders['quantity'].notna() &
    (valid_sales_orders['quantity'] > 0)
]

# 4. Keep only valid prices
valid_sales_orders = valid_sales_orders[
    valid_sales_orders['price'].notna() &
    (valid_sales_orders['price'] >= 0)
]

# 5. Convert order_date to datetime
valid_sales_orders['order_date'] = pd.to_datetime(
    valid_sales_orders['order_date'],
    errors='coerce'
)

# 6. Remove records with invalid order dates
valid_sales_orders = valid_sales_orders.dropna(
    subset=['order_date']
)

# 7. Keep only Completed orders
valid_sales_orders = valid_sales_orders[
    valid_sales_orders['status']
    .astype('string')
    .str.strip()
    .str.lower() == 'completed'
]

# 8. Reset the index
valid_sales_orders = valid_sales_orders.reset_index(drop=True)

# 9. Display the results
print("\nValid Completed Sales Orders:")
print(valid_sales_orders)

print("\nTotal Valid Sales Orders:", len(valid_sales_orders))


# STEP 17 — Join Orders with Products

print("\nSTEP 17: Joining Orders with Products")

# Merge valid sales orders with cleaned products
sales = pd.merge(
    valid_sales_orders,
    clean_products_df[['product_id', 'product_name', 'category', 'stock']],
    on='product_id',
    how='inner'
)

# Select the required columns
sales = sales[
    [
        'order_id',
        'customer_id',
        'product_id',
        'quantity',
        'price',
        'order_date',
        'status',
        'product_name',
        'category',
        'stock'
    ]
]

# Display the final result
print("\nOrders Joined with Products:")
print(sales)

print("\nTotal Sales Records:", len(sales))

# Save the result to a CSV file
sales.to_csv(
    "sales_with_products.csv",
    index=False
)

print("\nSales data saved successfully!")


# STEP 18 — Join with Customer Data

print("\nSTEP 18: Joining Sales with Customer Data")

# Merge sales data with cleaned customer data
final_sales = pd.merge(
    sales,
    customers_df[
        ['customer_id', 'customer_name', 'Email', 'City']
    ],
    on='customer_id',
    how='inner'
)

# Select the required columns
final_sales = final_sales[
    [
        'order_id',
        'customer_id',
        'customer_name',
        'Email',
        'City',
        'product_id',
        'product_name',
        'category',
        'quantity',
        'price',
        'stock',
        'order_date',
        'status'
    ]
]

# Display the final dataset
print("\nFinal Sales Dataset:")
print(final_sales)

print("\nTotal Final Sales Records:", len(final_sales))

# Save the final dataset
final_sales.to_csv(
    "final_sales_dataset.csv",
    index=False
)

print("\nFinal sales dataset saved successfully!")


# STEP 19 — Create Sales Calculations

print("\nSTEP 19: Calculating Sales Amount")

# 1. Calculate sales amount
final_sales['sales_amount'] = (
    final_sales['quantity'] * final_sales['price']
)

# 2. Display sales calculations
print("\nSales Amount Calculation:")
print(
    final_sales[
        ['order_id', 'quantity', 'price', 'sales_amount']
    ]
)

# 3. Check for missing sales amounts
missing_sales = final_sales['sales_amount'].isna().sum()

# 4. Check for negative sales amounts
negative_sales = (final_sales['sales_amount'] < 0).sum()

# 5. Check for infinite sales amounts
infinite_sales = (
    final_sales['sales_amount']
    .isin([float('inf'), float('-inf')])
    .sum()
)

# 6. Display validation results
print("\nSales Amount Validation Results")
print("Missing Sales Amounts:", missing_sales)
print("Negative Sales Amounts:", negative_sales)
print("Infinite Sales Amounts:", infinite_sales)

# 7. Overall validation status
if (
    missing_sales == 0
    and negative_sales == 0
    and infinite_sales == 0
):
    print("PASS: All calculated sales amounts are valid.")
else:
    print("FAIL: Invalid sales amounts detected.")

# 8. Save the calculated sales data
final_sales.to_csv(
    "final_sales_dataset.csv",
    index=False
)

print("\nSales calculations saved successfully!")


# STEP 20 — Create Business Summary

print("\nSTEP 20: Creating Business Summary")

# --------------------------------------------------
# 1. OVERALL BUSINESS SUMMARY
# --------------------------------------------------

overall_summary = pd.DataFrame({
    'total_completed_orders': [final_sales['order_id'].nunique()],
    'total_quantity_sold': [final_sales['quantity'].sum()],
    'total_sales': [final_sales['sales_amount'].sum()]
})

print("\n1. OVERALL BUSINESS SUMMARY")
print(overall_summary)


# --------------------------------------------------
# 2. PRODUCT-LEVEL SUMMARY
# --------------------------------------------------

product_summary = (
    final_sales.groupby('product_name', as_index=False)
    .agg(
        quantity_sold=('quantity', 'sum'),
        total_sales=('sales_amount', 'sum')
    )
    .sort_values(by='total_sales', ascending=False)
)

print("\n2. PRODUCT-LEVEL SUMMARY")
print(product_summary)


# --------------------------------------------------
# 3. CITY-LEVEL SUMMARY
# --------------------------------------------------

city_summary = (
    final_sales.groupby('City', as_index=False)
    .agg(
        total_sales=('sales_amount', 'sum')
    )
    .sort_values(by='total_sales', ascending=False)
)

print("\n3. CITY-LEVEL SUMMARY")
print(city_summary)


# --------------------------------------------------
# 4. CATEGORY-LEVEL SUMMARY
# --------------------------------------------------

category_summary = (
    final_sales.groupby('category', as_index=False)
    .agg(
        total_sales=('sales_amount', 'sum')
    )
    .sort_values(by='total_sales', ascending=False)
)

print("\n4. CATEGORY-LEVEL SUMMARY")
print(category_summary)


# --------------------------------------------------
# 5. PRODUCT WITH HIGHEST SALES
# --------------------------------------------------

if not product_summary.empty:
    highest_sales_product = product_summary[
        product_summary['total_sales']
        == product_summary['total_sales'].max()
    ]

    print("\n5. PRODUCT WITH HIGHEST SALES")
    print(highest_sales_product)
else:
    print("\nNo product sales data available.")


# ==========================================================
# PART 5 — OUTPUT
# STEP 21 — FINAL DATA QUALITY VALIDATION
# ==========================================================

print("\n" + "=" * 65)
print("STEP 21: FINAL DATA QUALITY VALIDATION")
print("=" * 65)

# ----------------------------------------------------------
# 1. INITIALIZE VALIDATION RESULTS
# ----------------------------------------------------------

validation_results = []


# ----------------------------------------------------------
# 2. VALIDATION FUNCTION
# ----------------------------------------------------------

def validate_check(check_name, condition):

    result = "PASS" if condition else "FAIL"

    validation_results.append({
        "check": check_name,
        "result": result
    })

    print(f"{result}: {check_name}")


# ----------------------------------------------------------
# 3. CUSTOMER DATA VALIDATION
# ----------------------------------------------------------

print("\n--- CUSTOMER DATA VALIDATION ---")

# Required customer columns
required_customer_columns = [
    "customer_id",
    "customer_name",
    "email",
    "city"
]

customer_columns_exist = all(
    col in customers_df.columns
    for col in required_customer_columns
)

validate_check(
    "Required customer columns exist",
    customer_columns_exist
)

# Continue customer checks only if required columns exist
if customer_columns_exist:

    # Check duplicate customer IDs
    validate_check(
        "No duplicate customer IDs",
        not customers_df["customer_id"].duplicated().any()
    )

    # Check missing or blank customer IDs
    customer_ids_valid = (
        customers_df["customer_id"].notna()
        & customers_df["customer_id"].astype("string").str.strip().ne("")
    )

    validate_check(
        "No missing or blank customer IDs",
        customer_ids_valid.all()
    )

    # Check unnecessary spaces in customer text columns
    customer_text_columns = [
        "customer_id",
        "customer_name",
        "Email",
        "City"
    ]

    customer_spaces_valid = all(
        customers_df[col].dropna().eq(
            customers_df[col].dropna().astype("string").str.strip()
        ).all()
        for col in customer_text_columns
    )

    validate_check(
        "No unnecessary leading or trailing spaces in customer data",
        customer_spaces_valid
    )

    # Check missing or blank required customer values
    customer_values_valid = (
        customers_df[required_customer_columns].notna().all().all()
        and all(
            customers_df[col].astype("string").str.strip().ne("").all()
            for col in required_customer_columns
        )
    )

    validate_check(
        "No missing required customer values",
        customer_values_valid
    )


# ----------------------------------------------------------
# 4. PRODUCT DATA VALIDATION
# ----------------------------------------------------------

print("\n--- PRODUCT DATA VALIDATION ---")

required_product_columns = [
    "product_id",
    "product_name",
    "category",
    "stock",
    "price"
]

product_columns_exist = all(
    col in clean_products_df.columns
    for col in required_product_columns
)

validate_check(
    "Required product columns exist",
    product_columns_exist
)

if product_columns_exist:

    # Check duplicate product IDs
    validate_check(
        "No duplicate product IDs",
        not clean_products_df["product_id"].duplicated().any()
    )

    # Check missing or blank product IDs
    product_ids_valid = (
        clean_products_df["product_id"].notna()
        & clean_products_df["product_id"].astype("string").str.strip().ne("")
    )

    validate_check(
        "No missing or blank product IDs",
        product_ids_valid.all()
    )

    # Check required product values
    required_product_values_valid = (
        clean_products_df[
            ["product_id", "product_name", "category", "stock", "price"]
        ].notna().all().all()
    )

    validate_check(
        "No missing required product values",
        required_product_values_valid
    )

    # Check product ID spaces
    product_id_spaces_valid = (
        clean_products_df["product_id"].dropna().astype("string").eq(
            clean_products_df["product_id"].dropna()
            .astype("string").str.strip()
        ).all()
    )

    validate_check(
        "No unnecessary spaces in product IDs",
        product_id_spaces_valid
    )

    # Check negative stock
    stock = pd.to_numeric(
        clean_products_df["stock"],
        errors="coerce"
    )

    validate_check(
        "No missing, invalid, or negative stock",
        stock.notna().all() and stock.ge(0).all()
    )

    # Check missing, invalid, or negative product prices
    product_price = pd.to_numeric(
        clean_products_df["price"],
        errors="coerce"
    )

    validate_check(
        "No missing, invalid, or negative product prices",
        product_price.notna().all()
        and product_price.ge(0).all()
    )


# ----------------------------------------------------------
# 5. ORDER DATA VALIDATION
# ----------------------------------------------------------

print("\n--- ORDER DATA VALIDATION ---")

required_order_columns = [
    "order_id",
    "customer_id",
    "product_id",
    "quantity",
    "price",
    "order_date",
    "status"
]

order_columns_exist = all(
    col in clean_orders_df.columns
    for col in required_order_columns
)

validate_check(
    "Required order columns exist",
    order_columns_exist
)

if order_columns_exist:

    # Check duplicate order IDs
    validate_check(
        "No duplicate order IDs",
        not clean_orders_df["order_id"].duplicated().any()
    )

    # Check missing or blank order IDs
    order_ids_valid = (
        clean_orders_df["order_id"].notna()
        & clean_orders_df["order_id"].astype("string").str.strip().ne("")
    )

    validate_check(
        "No missing or blank order IDs",
        order_ids_valid.all()
    )

    # Check customer IDs exist in cleaned customer data
    customer_ids_valid = (
        clean_orders_df["customer_id"].notna()
        & clean_orders_df["customer_id"].astype("string").str.strip().ne("")
        & clean_orders_df["customer_id"].isin(customers_df["customer_id"])
    )

    validate_check(
        "All order customer IDs exist in customer data",
        customer_ids_valid.all()
    )

    # Check product IDs exist in cleaned product data
    product_ids_valid = (
        clean_orders_df["product_id"].notna()
        & clean_orders_df["product_id"].astype("string").str.strip().ne("")
        & clean_orders_df["product_id"].isin(clean_products_df["product_id"])
    )

    validate_check(
        "All order product IDs exist in product data",
        product_ids_valid.all()
    )

    # Check quantity
    quantity = pd.to_numeric(
        clean_orders_df["quantity"],
        errors="coerce"
    )

    validate_check(
        "All quantities are valid and greater than zero",
        quantity.notna().all() and quantity.gt(0).all()
    )

    # Check order prices
    order_price = pd.to_numeric(
        clean_orders_df["price"],
        errors="coerce"
    )

    validate_check(
        "All order prices are valid and non-negative",
        order_price.notna().all() and order_price.ge(0).all()
    )

    # Check order dates
    order_dates = pd.to_datetime(
        clean_orders_df["order_date"],
        errors="coerce"
    )

    validate_check(
        "All order dates are valid",
        order_dates.notna().all()
    )

    # Check unwanted leading/trailing status spaces
    status_valid = (
        clean_orders_df["status"].notna()
        & clean_orders_df["status"].astype("string").eq(
            clean_orders_df["status"].astype("string").str.strip()
        )
    )

    validate_check(
        "No missing statuses or unwanted status spaces",
        status_valid.all()
    )


# ----------------------------------------------------------
# 6. FINAL SALES DATA VALIDATION
# ----------------------------------------------------------

print("\n--- FINAL SALES DATA VALIDATION ---")

required_sales_columns = [
    "order_id",
    "customer_id",
    "product_id",
    "quantity",
    "price",
    "order_date",
    "status",
    "sales_amount"
]

sales_columns_exist = all(
    col in final_sales.columns
    for col in required_sales_columns
)

validate_check(
    "Required final sales columns exist",
    sales_columns_exist
)

if sales_columns_exist:

    # Check that final sales customer IDs exist
    final_customer_ids_valid = (
        final_sales["customer_id"].notna()
        & final_sales["customer_id"].isin(customers_df["customer_id"])
    )

    validate_check(
        "All final sales customer IDs exist",
        final_customer_ids_valid.all()
    )

    # Check that final sales product IDs exist
    final_product_ids_valid = (
        final_sales["product_id"].notna()
        & final_sales["product_id"].isin(clean_products_df["product_id"])
    )

    validate_check(
        "All final sales product IDs exist",
        final_product_ids_valid.all()
    )

    # Check completed status only
    final_status_valid = (
        final_sales["status"].notna()
        & final_sales["status"].astype("string")
        .str.strip()
        .str.lower()
        .eq("completed")
    )

    validate_check(
        "Only completed orders exist in final sales",
        final_status_valid.all()
    )

    # Check sales_amount calculation
    sales_quantity = pd.to_numeric(
        final_sales["quantity"],
        errors="coerce"
    )

    sales_price = pd.to_numeric(
        final_sales["price"],
        errors="coerce"
    )

    actual_sales_amount = pd.to_numeric(
        final_sales["sales_amount"],
        errors="coerce"
    )

    expected_sales_amount = sales_quantity * sales_price

    sales_amount_valid = (
        sales_quantity.notna().all()
        and sales_quantity.gt(0).all()
        and sales_price.notna().all()
        and sales_price.ge(0).all()
        and actual_sales_amount.notna().all()
        and expected_sales_amount.notna().all()
        and actual_sales_amount.ge(0).all()
        and not actual_sales_amount.isin(
            [float("inf"), float("-inf")]
        ).any()
        and not expected_sales_amount.isin(
            [float("inf"), float("-inf")]
        ).any()
        and actual_sales_amount.reset_index(drop=True).equals(
            expected_sales_amount.reset_index(drop=True)
        )
    )

    validate_check(
        "sales_amount exists and equals quantity multiplied by price",
        sales_amount_valid
    )

    # Check invalid dates in final sales
    final_dates = pd.to_datetime(
        final_sales["order_date"],
        errors="coerce"
    )

    validate_check(
        "All final sales order dates are valid",
        final_dates.notna().all()
    )

    # Check duplicate order IDs in final sales.
    # Multiple rows per order may be legitimate if an order contains
    # multiple products, so this check is intentionally not included.


# ----------------------------------------------------------
# 7. CREATE FINAL VALIDATION REPORT
# ----------------------------------------------------------

print("\n" + "=" * 65)
print("FINAL DATA QUALITY REPORT")
print("=" * 65)

validation_report = pd.DataFrame(validation_results)

if validation_report.empty:

    print("No validation checks were executed.")
    print("OVERALL RESULT: FAIL")

else:

    print(validation_report.to_string(index=False))

    total_checks = len(validation_report)

    passed_checks = (
        validation_report["result"] == "PASS"
    ).sum()

    failed_checks = (
        validation_report["result"] == "FAIL"
    ).sum()

    print("\nTotal Checks:", total_checks)
    print("Passed Checks:", passed_checks)
    print("Failed Checks:", failed_checks)


    # ------------------------------------------------------
    # 8. SAVE OUTPUT FILES ONLY IF ALL CHECKS PASS
    # ------------------------------------------------------

    if (
        failed_checks == 0
        and total_checks > 0
    ):

        final_sales.to_csv(
            "final_sales_dataset.csv",
            index=False
        )

        overall_summary.to_csv(
            "overall_summary.csv",
            index=False
        )

        product_summary.to_csv(
            "product_summary.csv",
            index=False
        )

        city_summary.to_csv(
            "city_summary.csv",
            index=False
        )

        category_summary.to_csv(
            "category_summary.csv",
            index=False
        )

        validation_report.to_csv(
            "data_quality_report.csv",
            index=False
        )

        print("\nOVERALL RESULT: PASS")
        print("All final output files saved successfully!")

    else:

        print("\nOVERALL RESULT: FAIL")
        print("Output files were not saved.")
        print("Please correct the failed validations.")

# ==========================================================
# STEP 22 — GENERATE OUTPUT CSV FILES
# ==========================================================

import os
import pandas as pd

print("\n" + "=" * 60)
print("STEP 22: GENERATING OUTPUT CSV FILES")
print("=" * 60)

# 1. Create output folder
output_folder = "output"

os.makedirs(output_folder, exist_ok=True)

print(f"\nOutput folder created: {os.path.abspath(output_folder)}")


# ----------------------------------------------------------
# 2. SAVE CLEANED CUSTOMERS
# ----------------------------------------------------------

customers_df.to_csv(
    os.path.join(output_folder, "cleaned_customers.csv"),
    index=False
)

print("PASS: cleaned_customers.csv saved successfully")


# ----------------------------------------------------------
# 3. SAVE CLEANED PRODUCTS
# ----------------------------------------------------------

clean_products_df.to_csv(
    os.path.join(output_folder, "cleaned_products.csv"),
    index=False
)

print("PASS: cleaned_products.csv saved successfully")


# ----------------------------------------------------------
# 4. SAVE CLEANED ORDERS
# ----------------------------------------------------------

clean_orders_df.to_csv(
    os.path.join(output_folder, "cleaned_orders.csv"),
    index=False
)

print("PASS: cleaned_orders.csv saved successfully")


# ----------------------------------------------------------
# 5. SAVE FINAL SALES DATASET
# ----------------------------------------------------------

final_sales.to_csv(
    os.path.join(output_folder, "final_sales.csv"),
    index=False
)

print("PASS: final_sales.csv saved successfully")


# ----------------------------------------------------------
# 6. CREATE SALES SUMMARY
# ----------------------------------------------------------

sales_summary = pd.DataFrame({
    "total_completed_orders": [
        final_sales["order_id"].nunique()
    ],
    "total_quantity_sold": [
        final_sales["quantity"].sum()
    ],
    "total_sales": [
        final_sales["sales_amount"].sum()
    ]
})

sales_summary.to_csv(
    os.path.join(output_folder, "sales_summary.csv"),
    index=False
)

print("PASS: sales_summary.csv saved successfully")


# ----------------------------------------------------------
# 7. DISPLAY OUTPUT FILES
# ----------------------------------------------------------

print("\n" + "=" * 60)
print("ALL OUTPUT FILES GENERATED")
print("=" * 60)

print("\nOutput files:")

for filename in [
    "cleaned_customers.csv",
    "cleaned_products.csv",
    "cleaned_orders.csv",
    "final_sales.csv",
    "sales_summary.csv"
]:
    filepath = os.path.join(output_folder, filename)

    if os.path.exists(filepath):
        print(f"PASS: {filepath}")
    else:
        print(f"FAIL: {filepath}")

print("\nOutput generation completed!")

# ==========================================================
# STEP 24: CONNECT PYTHON TO MYSQL AND LOAD DATA
# ==========================================================

import pandas as pd
import mysql.connector
from mysql.connector import Error


connection = None
cursor = None

try:

    # ------------------------------------------------------
    # STEP 1: CONNECT TO MYSQL
    # ------------------------------------------------------

    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Aadvik@2023",
        database="ecommerce_dw"
    )

    cursor = connection.cursor()

    print("Successfully connected to MySQL!")

    # ------------------------------------------------------
    # STEP 2: CREATE REQUIRED TABLES
    # ------------------------------------------------------

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id VARCHAR(10) PRIMARY KEY,
            customer_name VARCHAR(255),
            Email VARCHAR(255),
            City VARCHAR(100)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_id VARCHAR(10)PRIMARY KEY,
            product_name VARCHAR(255),
            category VARCHAR(100),
            price DECIMAL(12,2),
            stock INT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id VARCHAR(10) PRIMARY KEY,
            customer_id VARCHAR(10),
            product_id VARCHAR(10),
            quantity INT,
            price DECIMAL(12,2),
            order_date DATE,
            status VARCHAR(50),

            CONSTRAINT fk_orders_customer
                FOREIGN KEY (customer_id)
                REFERENCES customers(customer_id),

            CONSTRAINT fk_orders_product
                FOREIGN KEY (product_id)
                REFERENCES products(product_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            order_id VARCHAR(10),
            customer_id VARCHAR(10),
            customer_name VARCHAR(255),
            City VARCHAR(100),
            product_id VARCHAR(10),
            product_name VARCHAR(255),
            category VARCHAR(100),
            quantity INT,
            price DECIMAL(12,2),
            sales_amount DECIMAL(14,2),
            order_date DATE,
            status VARCHAR(50),

            PRIMARY KEY (order_id, product_id),

            CONSTRAINT fk_sales_customer
                FOREIGN KEY (customer_id)
                REFERENCES customers(customer_id),

            CONSTRAINT fk_sales_product
                FOREIGN KEY (product_id)
                REFERENCES products(product_id),

            CONSTRAINT fk_sales_order
                FOREIGN KEY (order_id)
                REFERENCES orders(order_id)
        )
    """)

    print("All required tables are ready.")

    # ------------------------------------------------------
    # STEP 3: VALIDATE CUSTOMER AND PRODUCT DATA
    # ------------------------------------------------------

    customers_df = customers_df[
        ["customer_id", "customer_name", "Email", "City"]
    ].copy()

    products_df = clean_products_df[
        ["product_id", "product_name", "category", "price", "stock"]
    ].copy()

    # IDs must not be missing or duplicated.

    if customers_df["customer_id"].isna().any():
        raise ValueError("Customer IDs contain NULL values.")

    if customers_df["customer_id"].duplicated().any():
        raise ValueError("Duplicate customer IDs found.")

    if products_df["product_id"].isna().any():
        raise ValueError("Product IDs contain NULL values.")

    if products_df["product_id"].duplicated().any():
        raise ValueError("Duplicate product IDs found.")

    # ------------------------------------------------------
    # STEP 4: PREPARE ORDERS AND FIND INVALID REFERENCES
    # ------------------------------------------------------

    required_order_columns = [
        "order_id",
        "customer_id",
        "product_id",
        "quantity",
        "price",
        "order_date",
        "status"
    ]

    orders_df = clean_orders_df[
        required_order_columns
    ].copy()

    if orders_df["order_id"].isna().any():
        raise ValueError("Order IDs contain NULL values.")

    if orders_df["order_id"].duplicated().any():
        raise ValueError(
            "Duplicate order IDs found. Check whether order_id "
            "uniquely identifies a row in your source data."
        )

    # Check customer references.

    valid_customer_ids = set(customers_df["customer_id"])
    valid_product_ids = set(products_df["product_id"])

    missing_customer_mask = (
        ~orders_df["customer_id"].isin(valid_customer_ids)
    )

    missing_product_mask = (
        ~orders_df["product_id"].isin(valid_product_ids)
    )

    invalid_reference_mask = (
        missing_customer_mask | missing_product_mask
    )

    rejected_orders = orders_df[
        invalid_reference_mask
    ].copy()

    valid_orders = orders_df[
        ~invalid_reference_mask
    ].copy()

    print("\nOrder validation results:")
    print("Original orders:", len(orders_df))
    print("Valid orders:", len(valid_orders))
    print("Rejected orders:", len(rejected_orders))

    if not rejected_orders.empty:

        print("\nOrders with missing customer/product references:")

        print(
            rejected_orders[
                ["order_id", "customer_id", "product_id"]
            ].to_string(index=False)
        )

        # Save rejected records for investigation.
        rejected_orders.to_csv(
            "rejected_orders.csv",
            index=False
        )

        print(
            "Rejected records saved to rejected_orders.csv"
        )

    # ------------------------------------------------------
    # STEP 5: KEEP SALES CONSISTENT WITH VALID ORDERS
    # ------------------------------------------------------

    sales_df = final_sales[
        [
            "order_id",
            "customer_id",
            "customer_name",
            "City",
            "product_id",
            "product_name",
            "category",
            "quantity",
            "price",
            "sales_amount",
            "order_date",
            "status"
        ]
    ].copy()

    # Keep sales records only if their order, customer,
    # and product references are valid.

    valid_order_ids = set(valid_orders["order_id"])

    valid_sales_mask = (
        sales_df["order_id"].isin(valid_order_ids)
        & sales_df["customer_id"].isin(valid_customer_ids)
        & sales_df["product_id"].isin(valid_product_ids)
    )

    rejected_sales = sales_df[
        ~valid_sales_mask
    ].copy()

    sales_df = sales_df[
        valid_sales_mask
    ].copy()

    print("\nSales validation results:")
    print("Valid sales records:", len(sales_df))
    print("Rejected sales records:", len(rejected_sales))

    if not rejected_sales.empty:
        rejected_sales.to_csv(
            "rejected_sales.csv",
            index=False
        )

    # ------------------------------------------------------
    # STEP 6: PREPARE DATE COLUMNS
    # ------------------------------------------------------

    valid_orders["order_date"] = pd.to_datetime(
        valid_orders["order_date"],
        errors="raise"
    ).dt.date

    sales_df["order_date"] = pd.to_datetime(
        sales_df["order_date"],
        errors="raise"
    ).dt.date

    # ------------------------------------------------------
    # STEP 7: CONVERT DATAFRAMES INTO MYSQL-READY ROWS
    # ------------------------------------------------------

    def prepare_rows(df):

        result = []

        for row in df.itertuples(
            index=False,
            name=None
        ):

            cleaned_row = []

            for value in row:

                if pd.isna(value):
                    cleaned_row.append(None)

                elif hasattr(value, "item"):
                    cleaned_row.append(value.item())

                else:
                    cleaned_row.append(value)

            result.append(tuple(cleaned_row))

        return result

    # ------------------------------------------------------
    # STEP 8: INSERT CUSTOMERS
    # ------------------------------------------------------

    customers_sql = """
        INSERT INTO customers
        (customer_id, customer_name, Email, City)
        VALUES (%s, %s, %s, %s)

        ON DUPLICATE KEY UPDATE
            customer_name = VALUES(customer_name),
            Email = VALUES(Email),
            City = VALUES(City)
    """

    if not customers_df.empty:

        cursor.executemany(
            customers_sql,
            prepare_rows(customers_df)
        )

    print("\nCustomers loaded:", len(customers_df))

    # ------------------------------------------------------
    # STEP 9: INSERT PRODUCTS
    # ------------------------------------------------------

    products_sql = """
        INSERT INTO products
        (product_id, product_name, category, price, stock)
        VALUES (%s, %s, %s, %s, %s)

        ON DUPLICATE KEY UPDATE
            product_name = VALUES(product_name),
            category = VALUES(category),
            price = VALUES(price),
            stock = VALUES(stock)
    """

    if not products_df.empty:

        cursor.executemany(
            products_sql,
            prepare_rows(products_df)
        )

    print("Products loaded:", len(products_df))

    # ------------------------------------------------------
    # STEP 10: INSERT VALID ORDERS
    # ------------------------------------------------------

    orders_sql = """
        INSERT INTO orders
        (order_id, customer_id, product_id, quantity,
         price, order_date, status)

        VALUES (%s, %s, %s, %s, %s, %s, %s)

        ON DUPLICATE KEY UPDATE
            customer_id = VALUES(customer_id),
            product_id = VALUES(product_id),
            quantity = VALUES(quantity),
            price = VALUES(price),
            order_date = VALUES(order_date),
            status = VALUES(status)
    """

    if not valid_orders.empty:

        cursor.executemany(
            orders_sql,
            prepare_rows(valid_orders)
        )

    print("Valid orders loaded:", len(valid_orders))

    # ------------------------------------------------------
    # STEP 11: INSERT VALID SALES
    # ------------------------------------------------------

    sales_sql = """
        INSERT INTO sales
        (order_id, customer_id, customer_name, City,
         product_id, product_name, category, quantity,
         price, sales_amount, order_date, status)

        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)

        ON DUPLICATE KEY UPDATE
            customer_id = VALUES(customer_id),
            customer_name = VALUES(customer_name),
            City = VALUES(City),
            product_name = VALUES(product_name),
            category = VALUES(category),
            quantity = VALUES(quantity),
            price = VALUES(price),
            sales_amount = VALUES(sales_amount),
            order_date = VALUES(order_date),
            status = VALUES(status)
    """

    if not sales_df.empty:

        cursor.executemany(
            sales_sql,
            prepare_rows(sales_df)
        )

    print("Valid sales loaded:", len(sales_df))

    # ------------------------------------------------------
    # STEP 12: COMMIT TRANSACTION
    # ------------------------------------------------------

    connection.commit()

    print("\n====================================")
    print("ETL DATA LOADING COMPLETED!")
    print("Customers table updated.")
    print("Products table updated.")
    print("Orders table updated.")
    print("Sales table updated.")
    print("Transaction committed successfully.")
    print("====================================")

except Exception as e:

    if connection is not None and connection.is_connected():
        connection.rollback()

    print("\nERROR OCCURRED:", e)
    print("Transaction rolled back.")

finally:

    if cursor is not None:
        cursor.close()

    if connection is not None and connection.is_connected():
        connection.close()

    print("MySQL connection closed.")

