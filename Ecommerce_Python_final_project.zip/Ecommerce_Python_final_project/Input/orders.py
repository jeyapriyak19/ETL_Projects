import pandas as pd

orders = {
    'order_id': [
        'O1001', 'O1002', 'O1003', 'O1004', 'O1005',
        'O1006', 'O1007', 'O1008', 'O1009', 'O1010',
        'O1011', 'O1012', 'O1013', 'O1014', 'O1015',
        'O1016', 'O1017', 'O1018', 'O1019', 'O1020',
        'O1020'
    ],

    'customer_id': [
        'C101', 'C102', 'C103', 'C104', 'C105',
        'C106', 'C107', 'C108', 'C109', 'C110',
        'C101', 'C102', 'C103', 'C104', 'C105',
        'C106', 'C107', 'C108', 'C109', 'C110',
        'C110'
    ],

    'product_id': [
        'P101', 'P102', 'P108', 'P106', 'P103',
        'P104', 'P105', 'C999', 'P107', 'P110',
        'P108', 'P101', 'P999', 'P103', 'P104',
        'P105', 'P106', 'P107', 'P108', 'P109',
        'P109'
    ],

    'quantity': [
        1, 2, 1, 2, 3,
        1, 2, 1, 1, 2,
        2, 1, 5, 0, -1,
        -2, 1, 1, 1, 1,
        1
    ],

    'price': [
        55000, 800, 25000, 7000, 1500,
        12000, 2500, 15000, 9000, 3500,
        25000, 55000, 800, 1500, 12000,
        -2500, 7000, 9000, 25000, 15000,
        15000
    ],

    'order_date': [
        '2026-08-01', '2026-08-02', '2026-08-03', '2026-08-04',
        '2026-08-05', '2026-08-06', '2026-08-07', '2026-08-08',
        '2026-08-09', '2026-08-10', '2026-08-11', '2026-08-12',
        '2026-08-13', '2026-08-14', '2026-08-15', '2026-08-16',
        '', '2026-08-18', '2026/08/19', '2026-08-20',
        '2026-08-20'
    ],

    'status': [
        'Completed', 'Completed', 'Completed', 'Completed',
        'Cancelled ', 'Completed', 'Completed', 'Completed',
        'Completed', 'Completed', 'Completed', 'Completed',
        'Completed', 'Completed', 'Cancelled ', 'Completed',
        'Completed', 'Completed', 'Completed', 'Completed',
        'Completed'
    ]
}

df_orders = pd.DataFrame(orders)

df_orders.to_csv("orders.csv", index=False)

print("Orders CSV created successfully")
print(df_orders)