import pandas as pd
customer = {'customer_id':['C101','C102','C103','C104','C105','C106','C107','C108','C109','C110','c105','C111'],
            'customer_name':['Ravi Kumar','Priya Sharma','','Meena Raj','JOHN KUMAR','john kumar','Divya Singh','Anu Devi','Karthik Rao','David Raj','JOHN KUMAR','Kumar Das'],
            'Email':['ravi@gmail.com','','arun@gmail.com','meena@gmail.com','john@gmail.com','john.kumar@gmail.com','divya@gmail','anu@gmail.com','karthik@gmail.com','david@gmail.com','john@gmail.com','kumar@gmail.com'],
            'City':['Chennai','Chennai','Bangalore','Chennai','Mumbai','Mumbai','Bangalore','Chennai','','Delhi','Mumbai','Hyderabad']}

df = pd.DataFrame(customer)
df.to_csv("customer_source.csv", index=False)
print("Customer source CSV created successfully")
print(df)




