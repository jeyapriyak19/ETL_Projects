import pandas as pd

product = {
    'product_id': [
        'P101', 'P102', 'P103', 'P104', 'P105',
        'P106', 'P107', 'P108', 'P109', 'P110',
        'P106', 'P111'
    ],

    'product_name': [
        'Laptop', 'Mouse', 'Keyboard', 'Monitor', 'Headset',
        'Chair', 'Table', 'Mobile', 'Printer', 'Webcam',
        'Chair', 'Desk'
    ],

    'category': [
        'Electronics', 'electronics', '', 'Electronics',
        'ELECTRONICS', 'Furniture', 'Furniture', 'electronics',
        'Electronics', 'Electronics', 'Furniture', 'furniture'
    ],

    'price': [
        55000, 800, 1500, 12000, 2500,
        7000, 9000, 25000, '', 3500, 7000, 8500
    ],

    'stock': [
        20, 100, 50, 30, 40,
        -5, 15, 25, 10, 35, -5, 12
    ]
}

df_product = pd.DataFrame(product)

df_product.to_csv("product_source.csv", index=False)

print("Product CSV created successfully")
print(df_product)